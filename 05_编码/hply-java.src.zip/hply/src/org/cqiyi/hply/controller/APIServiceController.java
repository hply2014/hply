package org.cqiyi.hply.controller;

import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.cqiyi.hply.bean.ActionType;
import org.cqiyi.hply.bean.DownloadArgs;
import org.cqiyi.hply.bean.DownloadResult;
import org.cqiyi.hply.bean.UploadArgs;
import org.cqiyi.hply.bean.UploadResult;
import org.cqiyi.hply.common.Utility;
import org.cqiyi.hply.service.DownloadService;
import org.cqiyi.hply.service.UploadService;

@Controller
@RequestMapping(value = "/api", produces = "text/plain;charset=UTF-8")
public class APIServiceController {

	private static ObjectMapper mapper = new ObjectMapper();

	@ResponseBody
	@RequestMapping(value = "/!uuid", method = RequestMethod.GET)
	public String getrandomUUIDString() {
		UUID uid = UUID.randomUUID();

		return uid.toString().replace("-", "") + "，中国";
	}

	@ResponseBody
	@RequestMapping(value = "/download", method = RequestMethod.POST)
	public String download(@RequestParam("data") String data) {
		DownloadResult result = null;
		try {
			DownloadArgs args = mapper.readValue(data.getBytes("utf-8"),
					DownloadArgs.class);
			DownloadService srv = new DownloadService(args);
			result = srv.get();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			result = new DownloadResult();
			result.setMessage("处理中的未知异常：" + e.getMessage());
			result.setAction(ActionType.ERROR_PROCESSING);

			// 修改当前数据的错误状态
			if (StringUtils.isNotEmpty(result.getId())) {
				DownloadService.updateProcessingErrorStatus(result);
			}

			e.printStackTrace();
		}
		String json = Utility.EMPTY_STRING;
		try {
			json = new String(mapper.writeValueAsBytes(result), "utf-8");
		} catch (Exception e) {
			result.setMessage("返回中的未知异常：" + e.getMessage());
			result.setAction(ActionType.ERROR_RETURNING);
			json = result.toString();
			e.printStackTrace();
		}
		return json;
	}

	@ResponseBody
	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public String upload(@RequestParam("data") String data) {
		UploadResult result = null;
		try {
			UploadArgs bean = mapper.readValue(data.getBytes("utf-8"),
					UploadArgs.class);
			System.out.println(bean.toString());

			UploadService srv = new UploadService(bean);
			result = srv.commit();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			result = new UploadResult();
			result.setAction(ActionType.ERROR_PROCESSING);
			result.setMessage("处理中的未知异常：" + e.getMessage());
			e.printStackTrace();
		}

		String json = Utility.EMPTY_STRING;
		try {
			json = new String(mapper.writeValueAsBytes(result), "utf-8");
		} catch (Exception e) {
			result.setMessage("返回中的未知异常：" + e.getMessage());
			result.setAction(ActionType.ERROR_RETURNING);
			json = result.toString();
			e.printStackTrace();
		}

		Utility.println(json);

		return json;
	}

	public static void main(String[] args) {
		String data = "{" + "\"id\": \"8\"," + "\"deviceid\": \"设备号\","
				+ "\"appid\": \"应用号（guid）\","
				+ "\"clienttime\": \"yyyymmddhhmiss\","
				+ "\"userid\": \"登录用户ID（guid）\","
				+ "\"location\": \"上传时的GPS坐标\", " + "\"tokenid\": \"上一次的授权码\","
				+ "\"action\": \"1\"," + "\"target\": \"huiyijiyao\","
				+ "\"targetid\":\"70D4299C134848E685471C09FAA82A86\","
				+ "\"version\":\"0\"," + "\"values\": {"
				+ "    \"field1\": \"关于什么什么的会议\","
				+ "    \"field2\": \"北京市东城区\"," + "    \"field3\": \"你，我，他\","
				+ "    \"field4\": \"14：00~16：00\","
				+ "    \"version\": \"版本号\","
				+ "    \"location\": \"修改数据的GPS坐标，特殊符号：[{:‘“'\\\"?-]\",  "
				+ "    \"userid\": \"用户ID\","
				+ "    \"updatetime\": \"yyyymmddhhmiss\"" + "}" + "}";
		new APIServiceController().upload(data);

		return;
	}
}
