package org.cqiyi.hply.common;

import java.util.Date;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public final class JdbcTemplateContext {
	private static JdbcTemplate jt;

	static {
		Utility.logger.info("Initialize jdbc connection ...");

		BeanFactory factory = new ClassPathXmlApplicationContext("jt-context.xml");

		jt = (JdbcTemplate)factory.getBean("jdbcTemplate");
		Utility.logger.info("Database connection has been initialized。");

		//尝试获取数据库当前时间
		Date now = jt.queryForObject("SELECT SYSDATE FROM DUAL", Date.class);
		Utility.logger.info("database now time is:" + now);
	}

	public static JdbcTemplate get() {
		return jt;
	}
	
	private JdbcTemplateContext(){
		
	}
}
