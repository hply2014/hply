package org.cqiyi.hply.bean;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.cqiyi.hply.common.Utility;

public class DownloadResult {

	private int action = -1;
	private String id = Utility.EMPTY_STRING;
	private String message = Utility.EMPTY_STRING;
	private String ownerid = Utility.EMPTY_STRING;
	private String servertime = Utility.EMPTY_STRING;
	private String target = Utility.EMPTY_STRING;
	private String targetid = Utility.EMPTY_STRING;

	@JsonIgnore
	private String fields = Utility.EMPTY_STRING;

	public String getFields() {
		return fields;
	}

	public void setFields(String fields) {
		this.fields = fields;
	}

	private String tokenid = Utility.EMPTY_STRING;

	private Map<String, String> values = new HashMap<String, String>();

	public int getAction() {
		return action;
	}

	public String getId() {
		return id;
	}

	public String getMessage() {
		return message;
	}

	public String getOwnerid() {
		return ownerid;
	}

	public String getServertime() {
		return servertime;
	}

	public String getTarget() {
		return target;
	}

	public String getTargetid() {
		return targetid;
	}

	public String getTokenid() {
		return tokenid;
	}

	public Map<String, String> getValues() {
		return values;
	}

	public void setAction(int action) {
		this.action = action;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}

	public void setServertime(String servertime) {
		this.servertime = servertime;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public void setTargetid(String targetid) {
		this.targetid = targetid;
	}

	public void setTokenid(String tokenid) {
		this.tokenid = tokenid;
	}

	public void setValues(Map<String, String> values) {
		this.values = values;
	}

	@Override
	public String toString() {
		// TODO: 手工构造JSON
		return "这一块儿代码还没写呢";
	}

}
