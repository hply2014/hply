package org.cqiyi.hply.bean;

public class DownloadArgs {

	private int action;
	private String appid;
	private String clienttime;

	private String devicecode;

	/*
	 * 上一次下载数据的返回结果的队列ID
	 */
	private String id;

	private String location;

	private String message;

	private String tokenid;

	private String userid;
	
	public int getAction() {
		return action;
	}
	public String getAppid() {
		return appid;
	}
	public String getClienttime() {
		return clienttime;
	}
	public String getDevicecode() {
		return devicecode;
	}
	public String getId() {
		return id;
	}
	public String getLocation() {
		return location;
	}

	public String getMessage() {
		return message;
	}

	public String getTokenid() {
		return tokenid;
	}

	public String getUserid() {
		return userid;
	}

	public void setAction(int action) {
		this.action = action;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public void setClienttime(String clienttime) {
		this.clienttime = clienttime;
	}

	public void setDevicecode(String devicecode) {
		this.devicecode = devicecode;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setTokenid(String tokenid) {
		this.tokenid = tokenid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}
