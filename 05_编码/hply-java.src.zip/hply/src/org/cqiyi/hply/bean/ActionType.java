package org.cqiyi.hply.bean;

public class ActionType {

	/*
	 * 数据插入
	 */
	final public static int INSERT = 1;
	

	/*
	 * 数据修改
	 */
	final public static int UPDATE  = 2;
	
	/*
	 * 数据删除
	 */
	final public static int DELETE  = 3;
	
	/*
	 * 处理过程中的未知异常
	 */
	final public static int ERROR_PROCESSING = 310;

	/*
	 * 返回的结果JSON串解析时的未知异常
	 */
	final public static int ERROR_RETURNING = 320;
	
	/*
	 * 下载队列为空
	 */
	final public static int EMPTY_QUEUE = 220;
	
}
