package org.cqiyi.hply.bean;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import org.cqiyi.hply.common.JdbcTemplateContext;

public class UploadArgs {
	private String id;
	private String devicecode;

	public String getDevicecode() {
		return devicecode;
	}

	public void setDevicecode(String devicecode) {
		this.devicecode = devicecode;
	}

	private String appid;
	private String clienttime;
	private String userid;
	private String location;
	private String tokenid;
	private int action;
	private String target;
	private String targetid;
	private int version;
	private String ownerid;

	public String getOwnerid() {
		// 如果客户端没有制定所有者，则根据设备编号和应用ID，重新获取所有者，获取不到会报错
		if (StringUtils.isEmpty(ownerid)) {
			String str = "select id from t_system_owner where devicecode=? and appid=?";
			ownerid = JdbcTemplateContext.get().queryForObject(str,
					String.class, this.devicecode, this.appid);
		}
		return ownerid;
	}

	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getClienttime() {
		return clienttime;
	}

	public void setClienttime(String clienttime) {
		this.clienttime = clienttime;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getTokenid() {
		return tokenid;
	}

	public void setTokenid(String tokenid) {
		this.tokenid = tokenid;
	}

	public int getAction() {
		return action;
	}

	public void setAction(int action) {
		this.action = action;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String getTargetid() {
		return targetid;
	}

	public void setTargetid(String targetid) {
		this.targetid = targetid;
	}

	public Map<String, String> getValues() {
		return values;
	}

	public void setValues(Map<String, String> values) {
		this.values = values;
	}

	private Map<String, String> values;

	@Override
	public String toString() {
		return this.id + "\n" + this.targetid + "\n" + this.values.size();
	}
}
