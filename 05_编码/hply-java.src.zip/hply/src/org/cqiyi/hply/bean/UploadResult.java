package org.cqiyi.hply.bean;

import java.text.MessageFormat;

import org.cqiyi.hply.common.Utility;

public class UploadResult {

	private String id = Utility.EMPTY_STRING;
	private int action = -1;
	private String message = Utility.EMPTY_STRING;
	private int version = -1;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getAction() {
		return action;
	}

	public void setAction(int action) {
		Utility.println("action=" + action);
		this.action = action;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message += message;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public String toString() {
		String json = MessageFormat
				.format("{\"id\":\"{0}\", \"action\":\"{1}\", \"message\":\"{2}\", \"version\":\"{3}\"}",
						this.id, this.action, this.message, this.version);
		return json;
	}

}
