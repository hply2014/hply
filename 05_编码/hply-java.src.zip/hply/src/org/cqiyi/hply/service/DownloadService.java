package org.cqiyi.hply.service;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;

import org.cqiyi.hply.bean.ActionType;
import org.cqiyi.hply.bean.DownloadArgs;
import org.cqiyi.hply.bean.DownloadResult;

public class DownloadService extends BaseService {

	private DownloadArgs args = null;

	public DownloadService(DownloadArgs args) {
		synchronized (this) {
			this.args = args;
		}

		// TODO: 更新上次数据状态及客户端的处理结果
		updatePriorStatus();

	}

	public DownloadService() {
		// TODO Auto-generated constructor stub
	}

	public DownloadResult get() {
		// 获取指定设备，指定应用的下载队列，队首的数据行
		DownloadResult result = null;
		try {
			result = jdbcTemplate
					.queryForObject(
							"select * from t_system_queue where rownum=1 and action<100 and ownerid in (select ownerid from t_system_owner where devicecode=? and appid=?) order by id asc",
							new RowMapper<DownloadResult>() {
								public DownloadResult mapRow(ResultSet rs,
										int rowNum) throws SQLException {
									DownloadResult item = new DownloadResult();
									item.setId(rs.getString("id"));
									item.setAction(rs.getInt("action"));
									item.setTarget(rs.getString("tablename"));
									item.setTargetid(rs.getString("dataid"));
									item.setOwnerid(rs.getString("ownerid"));
									item.setFields(rs.getString("fields"));
									return item;
								}
							}, args.getDevicecode(), args.getAppid());
		} catch (EmptyResultDataAccessException e) {
			result = new DownloadResult();
			result.setAction(ActionType.EMPTY_QUEUE);
			return result;
		}

		// 将刚取出的数据状态更新为下载中
		jdbcTemplate.update(
				"update t_system_queue set action=action+100 where id=?",
				result.getId());

		// 根据修改的字段列表，读取业务表数据
		if (StringUtils.isNotEmpty(result.getFields())) {
			Map<String, String> v = jdbcTemplate.queryForObject("select "
					+ result.getFields() + " from " + result.getTarget()
					+ " where id=?", new RowMapper<Map<String, String>>() {
				public Map<String, String> mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					Map<String, String> item = new HashMap<String, String>();
					ResultSetMetaData metaData = rs.getMetaData();

					// metaData数据从第1列开始，所以i=1
					for (int i = 1; i < metaData.getColumnCount(); ++i) {
						item.put(metaData.getColumnLabel(i).toLowerCase(),
								rs.getString(i));
					}
					return item;
				}
			}, result.getTargetid());
			result.getValues().putAll(v);
		}// end of if

		return result;
	}

	public static void updateProcessingErrorStatus(DownloadResult result) {
		String str = "update t_system_queue set retmessage=?, failcount=failcount+1, action="
				+ ActionType.ERROR_PROCESSING + " where id=?";

		jdbcTemplate.update(str, result.getMessage(), result.getId());
	}

	public void updatePriorStatus() {
		String str = null;
		if (args.getAction() < 300 && args.getAction() >= 200) {
			str = "update t_system_queue set retmessage=?, failcount=0, action=? where id=?";

		} else {
			str = "update t_system_queue set retmessage=?, failcount=failcount+1, action=? where id=?";

		}
		jdbcTemplate.update(str, args.getMessage(), args.getAction(),
				args.getId());

	}
}
