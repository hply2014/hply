package org.cqiyi.hply.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import org.cqiyi.hply.bean.UploadArgs;
import org.cqiyi.hply.bean.UploadResult;
import org.cqiyi.hply.bean.ActionType;
import org.cqiyi.hply.common.Utility;

public class UploadService extends BaseService {

	UploadArgs args = null;

	public UploadService(UploadArgs args) {
		synchronized (this) {
			this.args = args;
		}
		args.getValues().put("ownerid", args.getOwnerid());
	}

	public UploadService() {
		// TODO Auto-generated constructor stub
	}

	public UploadResult commit() {
		// TODO: 在此，向数据库提交数据
		UploadResult result = new UploadResult();
		result.setId(args.getId());

		int count = 0;
		String strv = "select version from " + args.getTarget() + " where id=?";
		try {
			int version = this.QueryForInt(strv, args.getTargetid());

			// 比较数据版本，SV表示Server Version；CV表示client Version
			if (args.getVersion() < version) {
				result.setMessage("数据版本冲突，SV：" + version + ", CV："
						+ args.getVersion() + "\n");
			}

			// 执行
			count = jdbcTemplate.update(getSql());

			// 执行后，返回更新后的版本号
			if (args.getAction() != ActionType.DELETE) {
				result.setVersion(this.QueryForInt(strv, args.getTargetid()));
			}

			// 更新影响的记录行数
			result.setMessage("affected：" + count + "\n");
			// 201，插入成功，202，修改成功，203删除成功
			result.setAction(args.getAction() + 200);

			// //下载队列长度
			// String strc =
			// "select count(id) from t_system_queue where ownerid in (select ownerid from t_system_owner where devicecode=? and appid=?)";
			// result.setLength(this.QueryForInt(strc, bean.getDeviceid(),
			// bean.getAppid()));

		} catch (Exception ex) {

			// 301，插入失败，302，修改失败，303删除失败
			result.setAction(args.getAction() + 300);
			result.setMessage(ex.getMessage() + "\n");
			ex.printStackTrace();
		}

		return result;
	}

	private String getSql() {
		String str = Utility.EMPTY_STRING;
		Map<String, String> map = args.getValues();

		switch (args.getAction()) {
		case ActionType.INSERT:
			List<String> k = new ArrayList<String>();
			List<String> v = new ArrayList<String>();

			k.add("id");
			v.add("'" + args.getTargetid().replaceAll("'", "''") + "'");

			for (String key : map.keySet()) {
				// TODO：在这里对列名和数据进行处理
				k.add(key);
				v.add("'" + map.get(key).replaceAll("'", "''") + "'");
			}

			str = "insert into " + args.getTarget() + "("
					+ StringUtils.join(k, ",") + ") values("
					+ StringUtils.join(v, ",") + ")";

			break;
		case ActionType.UPDATE:
			List<String> fields = new ArrayList<String>();
			for (String key : map.keySet()) {
				// TODO：在这里对列名和数据进行处理
				fields.add(key + "='" + map.get(key).replaceAll("'", "''")
						+ "'");
			}
			str = "update " + args.getTarget() + " set "
					+ StringUtils.join(fields, ",")
					+ ",version=version+1 where id='"
					+ args.getTargetid().replaceAll("'", "''") + "'";
			break;
		case ActionType.DELETE:
			str = "delete from " + args.getTarget() + " where id='"
					+ args.getTargetid().replaceAll("'", "''") + "'";
			break;
		}

		return str;
	}
}
