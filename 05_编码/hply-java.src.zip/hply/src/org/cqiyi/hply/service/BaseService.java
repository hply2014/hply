package org.cqiyi.hply.service;

import java.util.Date;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import org.cqiyi.hply.common.JdbcTemplateContext;

public class BaseService {

	protected static JdbcTemplate jdbcTemplate = JdbcTemplateContext.get();

	public BaseService() {

	}

	public Date Test() {
		Date i = jdbcTemplate.queryForObject("SELECT SYSDATE FROM DUAL",
				Date.class);
		System.out.println("i=" + i);
		return i;
	}

	public int QueryForInt(String sql, Object... args) {
		int i = 0;
		try {
			i = jdbcTemplate.queryForObject(sql, Integer.class, args);
		} catch (DataAccessException ex) {
			ex.printStackTrace();
		}
		return i;
	}

}
