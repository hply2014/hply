CREATE DATABASE  IF NOT EXISTS `hplydb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `hplydb`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: hplydb
-- ------------------------------------------------------
-- Server version	5.6.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_sys_user`
--

DROP TABLE IF EXISTS `t_sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_sys_user` (
  `ID` char(36) NOT NULL,
  `LoginName` varchar(50) DEFAULT NULL,
  `RealName` varchar(50) DEFAULT NULL,
  `OrganizationID` char(36) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `LastLoginIp` varchar(50) DEFAULT NULL,
  `LastLoginTime` datetime DEFAULT NULL,
  `Fails` int(11) DEFAULT '0',
  `Logined` int(11) DEFAULT '0',
  `Position` varchar(50) DEFAULT NULL,
  `Enabled` int(11) DEFAULT '1',
  `OrderBy` int(11) DEFAULT '0',
  `CreateTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `create_user` char(36) DEFAULT NULL,
  `UpdateTime` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdateUser` char(36) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sys_user`
--

LOCK TABLES `t_sys_user` WRITE;
/*!40000 ALTER TABLE `t_sys_user` DISABLE KEYS */;
INSERT INTO `t_sys_user` VALUES ('8e1d9e90-06a0-11e4-99f8-6cf049046039','dujuan','杜鹃','财务部',NULL,NULL,NULL,0,0,'财务总监，系统管理员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e1fa629-06a0-11e4-99f8-6cf049046039','zhangmeng','张梦','财务部',NULL,NULL,NULL,0,0,'财务经理',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e227c03-06a0-11e4-99f8-6cf049046039','liuyuecui','刘月翠','财务部',NULL,NULL,NULL,0,0,'财务核算员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e242da5-06a0-11e4-99f8-6cf049046039','wangshuyan','王书岩','财务部',NULL,NULL,NULL,0,0,'盖章经办人',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e27dbbd-06a0-11e4-99f8-6cf049046039','yangdeyou','杨德友','项目部',NULL,NULL,NULL,0,0,'项目部负责人',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e2971a4-06a0-11e4-99f8-6cf049046039','wangyong','王勇','项目部',NULL,NULL,NULL,0,0,'项目部操作员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e2b2057-06a0-11e4-99f8-6cf049046039','xiadongyan','夏冬燕','项目部',NULL,NULL,NULL,0,0,'项目部操作员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e2cf6f9-06a0-11e4-99f8-6cf049046039','zhangyan','张岩','项目部',NULL,NULL,NULL,0,0,'项目部操作员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e2ecd14-06a0-11e4-99f8-6cf049046039','wangpeng','王鹏','项目部',NULL,NULL,NULL,0,0,'项目部操作员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e318892-06a0-11e4-99f8-6cf049046039','wangyouqing','王有青','事业部',NULL,NULL,NULL,0,0,'事业部负责人',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e332e52-06a0-11e4-99f8-6cf049046039','zhoukai','周楷','事业部',NULL,NULL,NULL,0,0,'项目部操作员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL),('8e34d5da-06a0-11e4-99f8-6cf049046039','wangjiaxin','王佳鑫','事业部',NULL,NULL,NULL,0,0,'项目部操作员',1,0,'2014-07-08 21:05:28',NULL,'2014-07-08 21:05:28',NULL,NULL);
/*!40000 ALTER TABLE `t_sys_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-15 23:38:30
